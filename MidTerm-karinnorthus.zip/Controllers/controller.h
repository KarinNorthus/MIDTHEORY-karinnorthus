#include <string.h>
#include "../Models/model.h"

Node *createNode (pasien P){
    Node *temp = (Node*)malloc(sizeof(Node));

    temp->P.date = P.date;
    strcpy(temp->P.month, P.month);
    temp->P.year = P.year;
    strcpy(temp->P.name, P.name);
    temp->next = NULL;
    temp->prev = NULL;

    return temp;
}

void pushPQ(pasien P, int total){
    Node *temp = createNode(P);
    if(!head){
        head = tail = temp;
    }

    else if(P.total < head->P.total){
        temp ->next = head;
        head ->prev = temp;
        head = temp;
    }
    else if(P.total > tail->P.total){
        temp ->prev = tail;
        tail ->next = temp;
        tail = temp;
    }
    else{
        Node *curr = head;

        while(curr && curr->next->P.total < temp->P.total){
            curr = curr->next;
        }

        curr->next->prev = temp;
        temp->next = curr->next;
        curr->next = temp;
        temp->prev = curr;
        
    }

}

void popHead(){
     if(head && head==tail){ 
        head = tail = NULL;
        free(head);
    }
    else{ 
        Node *newHead = head ->next; 
        head->next = newHead->prev = NULL; 
        free(head); 
        head = newHead; 
    }
}

void printLinkedList(){
    if(head == NULL){
        return;
    }

    else{
        curr = head;

        while(curr != NULL){
            printf("%d %s %d - %s\n", curr->P.date, curr->P.month, curr->P.year, curr->P.name);
            curr = curr ->next;
         }
    }
}


int countMonth(char *month){
    int bulan = 0;
    if(strcmp(month, "january")){
        bulan = 31;
    }
    else if (strcmp(month, "february")){
        bulan = 28;
    }
    else if(strcmp(month, "march")){
        bulan = 31;
    }
    else if(strcmp(month, "april")){
        bulan = 30;
    }
    else if(strcmp(month, "may")){
        bulan = 31;
    }
    else if(strcmp(month, "june")){
        bulan = 30;
    }
    else if(strcmp(month, "july")){
        bulan = 31;
    }
    else if(strcmp(month, "august")){
        bulan = 31;
    }
    else if(strcmp(month, "september")){
        bulan = 30;
    }
    else if(strcmp(month, "october")){
        bulan = 31;
    }
    else if(strcmp(month, "november")){
        bulan = 30;
    }
    else if(strcmp(month, "december")){
        bulan = 31;
    }

    return bulan;

}
