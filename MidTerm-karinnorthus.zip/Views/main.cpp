#include <stdio.h>
#include "../Controllers/controller.h"

int main(){
    int patients, cure, tahun;
    scanf("%d %d", &patients, &cure);

    pasien temp;
    for(int i = 1; i<=patients; i++){
        
        scanf("%d %s %d - %[^\n]", &temp.date, temp.month, &temp.year, temp.name);
        getchar();

        int bulan = countMonth(temp.month);
        temp.total = 0;

        for(int i = temp.year; i<=2020; i++){
            if(i%4==0){
                tahun = 366;
            }
            else{
                tahun = 365;
            }
        }

        temp.total = temp.date + bulan + tahun;

        pushPQ(temp, temp.total);
    }

    for(int j = 1; j <= cure ; j++){
        popHead();
    }

    if(cure > patients){
        int sisa = cure - patients;
        printf("All patients get the cure, %d cure left\n", sisa );
    }
    else{
        int tes = patients - cure;
        printf("Need %d more cure\n", tes);
        printLinkedList();
    }
    
    return 0;
}