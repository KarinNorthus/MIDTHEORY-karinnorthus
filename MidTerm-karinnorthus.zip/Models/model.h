#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct pasien{
    int date;
    char month[20];
    int year;
    char name[255];
    int total;

};

struct Node {
    pasien P;

    Node *next, *prev;
}*head, *tail, *curr;

